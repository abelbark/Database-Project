This is Phase II for group 15, Rodolfo Rivera, Abel Abarca, Jose Flores.
For phase II contributions:
Rodolfo Rivera - Initialize Database, Search functionality, recorded and uploaded demo video.
Abel Abarca - Insert item functionality.
Jose Flores - Review functionality.

Video link: https://www.youtube.com/watch?v=Le8kX-pHLVE&ab_channel=Rodolfo